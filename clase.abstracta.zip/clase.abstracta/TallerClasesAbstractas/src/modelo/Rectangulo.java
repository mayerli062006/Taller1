
package modelo;
//subclase que representa un rectangulo
public class Rectangulo extends FiguraGeometrica {
    private double base, altura;//atributos propios del triangulo
//constructo que inializa base y altura
    public Rectangulo(double base, double altura) {
        super("Rectángulo");
        this.base = base;
        this.altura = altura;
    }
//  se calcula el área del rectángulo.
    @Override
    public double calcularArea() {
        return base * altura;
    }
}
