package modelo;
//Clase principal para probar las figuras geométricas.
import modelo.*;

public class Main {
    public static void main(String[] args) {
        // se crean objetos de cada tipo de figura
        FiguraGeometrica c = new Circulo(5);
        FiguraGeometrica r = new Rectangulo(4, 6);
        FiguraGeometrica t = new Triangulo(3, 7);
//se muestra la informacion de cada tipo de figura

        c.mostrarInfo();
        r.mostrarInfo();
        t.mostrarInfo();
    }
}

