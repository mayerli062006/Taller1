

package modelo;
//subclase que representa un triangulo
public class Triangulo extends FiguraGeometrica {
    private double base, altura;//atributos del triangulo
//constructo que inicializa base y altura
    public Triangulo(double base, double altura) {
        super("Triángulo");
        this.base = base;
        this.altura = altura;
    }
// se calcula el area del triangulo
    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }
}
