
package modelo;
//subclase que representa un circulo
         public class Circulo extends FiguraGeometrica {
        private double radio;//atributo especifico del circulo
         // Constructor que recibe el radio y llama al constructor de la superclase
          public Circulo(double radio) {
              super("Círculo");
            this.radio = radio;
    }
//se implementa el método abstracto calcularArea().
         @Override
            public double calcularArea() {
         return Math.PI * radio * radio;
    }
}





