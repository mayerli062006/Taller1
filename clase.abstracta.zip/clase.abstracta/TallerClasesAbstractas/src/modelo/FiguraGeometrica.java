//
package modelo;

       public abstract class FiguraGeometrica {
    protected String nombre;

         public FiguraGeometrica(String nombre) {
        this.nombre = nombre;
    }

    // Método abstracto 
              public abstract double calcularArea();

    // Método concreto 
    public void mostrarInfo() {
        System.out.println("Figura: " + nombre + 
                           " | Área: " + calcularArea());
    }
}



