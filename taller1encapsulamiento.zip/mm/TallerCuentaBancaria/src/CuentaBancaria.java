// Definimos la clase CuentaBancaria
public class CuentaBancaria {

    // Atributos privados 
    private String numeroCuenta;
    private double saldo;

    
    public CuentaBancaria(String numeroCuenta, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
    }

    // Método para depositar dinero
    public void depositar(double monto) {
        if (monto > 0) {
            saldo += monto;
            System.out.println("Depósito de $" + monto + " realizado en la cuenta " + numeroCuenta);
        } else {
            System.out.println("Monto inválido para depositar.");
        }
    }

    // Método para retirar dinero si hay fondos suficientes
    public void retirar(double monto) {
        if (monto > 0) {
            if (saldo >= monto) {
                saldo -= monto;
                System.out.println("Retiro de $" + monto + " realizado en la cuenta " + numeroCuenta);
            } else {
                System.out.println("Fondos insuficientes en la cuenta " + numeroCuenta);
            }
        } else {
            System.out.println("Monto inválido para retirar.");
        }
    }

    // Getters para consultar información
    public double getSaldo() {
        return saldo;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }
}
