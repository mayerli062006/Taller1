 public class Main {
    public static void main(String[] args) {

        // Creamos dos cuentas bancarias
        CuentaBancaria cuenta1 = new CuentaBancaria("001", 1000.0);
        CuentaBancaria cuenta2 = new CuentaBancaria("002", 500.0);

        // Operaciones con cuenta1
        cuenta1.depositar(300.0);
        cuenta1.retirar(200.0);

        // Operaciones con cuenta2
        cuenta2.depositar(100.0);
        cuenta2.retirar(700.0);  // No debe permitir porque no hay suficiente dinero

        // Mostrar saldos finales
        System.out.println("\n Saldos Finales ");
        System.out.println("Cuenta " + cuenta1.getNumeroCuenta() + ": $" + cuenta1.getSaldo());
        System.out.println("Cuenta " + cuenta2.getNumeroCuenta() + ": $" + cuenta2.getSaldo());
    }
}
