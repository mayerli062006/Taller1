/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller3;

//by mm
public class Main {
    public static void main(String[] args) {
        // Crear un objeto Producto
        producto producto = new producto("Laptop", 1500, 10);
        // Mostramos la información inicial del producto
        producto.mostrarInfo();

        //  modificar el precio con un valor no permitido (menor a 1000)
        producto.setPrecio(900); // Esto no debería cambiar el precio

        // Modificar el precio con un valor válido
        producto.setPrecio(2000); // Esto debería funcionar

        // Intentar modificar el stock con un valor negativo
        producto.setStock(-5); // Esto no debería cambiar el stock

        // Modificar el stock con un valor válido
        producto.setStock(20); // Esto debería funcionar

        // Mostrar la información después de modificar precio y stock
        producto.mostrarInfo();

        // Simular ventas
        producto.vender(5); // Se deben vender 5 unidades

        // Intentar vender más unidades de las que hay en stock
        producto.vender(20); // Esto debería mostrar un mensaje de error porque el stock es insuficiente

        // Mostrar la información después de realizar ventas
        producto.mostrarInfo();
    }
}
