
package taller3;

public class producto {

    // Atributos privados 
    private String nombre;
    private double precio;
    private int stock;

    // Constructor
    public producto(String nombre, double precio, int stock) {
        this.nombre = nombre; 
        setPrecio(precio);     
        setStock(stock);        
    }

    // Getters y Setters para el atributo 'nombre'
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para el atributo 'precio'
    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        // Validación para que el precio no sea menor que 1000
        if (precio < 1000) {
            System.out.println("El precio no puede ser menor a 1000.");
        } else {
            this.precio = precio;
        }
    }

    // Getter y Setter para el atributo 'stock'
    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        // Validación para que el stock no sea negativo
        if (stock < 0) {
            System.out.println("El stock no puede ser negativo.");
        } else {
            this.stock = stock;
        }
    }

    // Método para vender productos
    public void vender(int cantidad) {
        if (cantidad <= stock) {
            stock -= cantidad; // Disminuye el stock
            System.out.println("Se han vendido " + cantidad + " unidades.");
        } else {
            System.out.println("No hay suficiente stock para vender esa cantidad.");
        }
    }

    // Método para mostrar información del producto
    public void mostrarInfo() {
        System.out.println("Producto: " + nombre);
        System.out.println("Precio: " + precio);
        System.out.println("Stock disponible: " + stock);
    }

}

