/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller4;
public class libro {

    // Atributos privados
    private String titulo;
    private String autor;
    private int paginas;

    // Constructor vacío (por si necesitamos crear un libro sin especificar datos iniciales)
    public libro() {}

    // Constructor con parámetros
    public libro(String titulo, String autor, int paginas) {
        this.titulo = titulo;
        this.autor = autor;
        setPaginas(paginas); // Usamos el setter de paginas para validar
    }

    // Getter y Setter para el atributo 'titulo'
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter y Setter para el atributo 'autor'
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    // Getter y Setter para el atributo 'paginas'
    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        if (paginas > 10) {
            this.paginas = paginas;
        } else {
            System.out.println("El número de páginas debe ser mayor que 10.");
        }
    }

    // Método para mostrar la información del libro
    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + paginas);
    }

    // Método main para probar la clase Libro
    public static void main(String[] args) {
        // Crear dos objetos Libro
        libro libro1 = new libro("Los miserables", "Victor Hugo", 1782);
        libro libro2 = new libro("Cien Años de Soledad", "Gabriel García Márquez", 200);

        // Mostrar la información de ambos libros
        System.out.println("Información del primer libro:");
        libro1.mostrarInfo();
        System.out.println();

        System.out.println("Información del segundo libro:");
        libro2.mostrarInfo();
    }
}

