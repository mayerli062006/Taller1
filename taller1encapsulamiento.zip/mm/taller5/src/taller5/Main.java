/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller5;

/**
 *
 * @author SENA
 */
public class Main {

    public static void main(String[] args) {
        // Crear un objeto Empleado
        Empleado empleado1 = new Empleado("sara garcia", 1500000);

        // Mostrar la información inicial
        System.out.println("Información inicial del empleado:");
        empleado1.mostrarInfo();
        System.out.println();

        // Cambiar el salario a un valor inválido
        empleado1.setSalario(1200000); 

        // Cambiar el salario a un valor válido
        empleado1.setSalario(1800000); 

        // Aumentar el salario en un 10%
        empleado1.aumentarSalario(10);

        // Mostrar la información después del aumento
        System.out.println();
        empleado1.mostrarInfo();
    }
}

