
package taller5;

//by mm
public class Empleado {

    // Atributos privados
    private String nombre;
    private double salario;

    // Constructor con parámetros
    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        setSalario(salario); 
    }

    // Getter y Setter para el atributo 'nombre'
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para el atributo 'salario'
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        // Validación para asegurar que el salario no sea menor al salario mínimo
        double salarioMinimo = 1300000;
        if (salario < salarioMinimo) {
            System.out.println("El salario no puede ser menor al salario mínimo (" + salarioMinimo + ")");
        } else {
            this.salario = salario;
        }
    }

    // Método para aumentar el salario
    public void aumentarSalario(double porcentaje) {
        double aumento = salario * porcentaje / 100;
        salario += aumento; // Aumenta el salario en el porcentaje dado
        System.out.println("El salario ha aumentado un " + porcentaje + "%.");
    }

    // Método para mostrar la información del empleado
    public void mostrarInfo() {
        System.out.println("Nombre del empleado: " + nombre);
        System.out.println("Salario: " + salario);
    }
}

