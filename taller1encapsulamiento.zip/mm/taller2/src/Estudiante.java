public class Estudiante {

    // Atributos privados
    private String nombre;
    private double nota;

   
    public Estudiante(String nombre, double nota) {
        this.nombre = nombre;
        setNota(nota);  // Usamos el setter para validar la nota
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para nota
    public double getNota() {
        return nota;
    }

    // Setter para nota con validación (debe estar entre 0 y 5)
    public void setNota(double nota) {
        if (nota >= 0 && nota <= 5) {
            this.nota = nota;
        } else {
            System.out.println("Nota inválida. Debe estar entre 0 y 5.");
        }
    }

    // Método para mostrar información del estudiante
    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Nota: " + nota);
    }
}

