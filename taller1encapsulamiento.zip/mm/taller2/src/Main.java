public class Main {
    public static void main(String[] args) {
        // Creamos un estudiante con nota válida
        Estudiante est1 = new Estudiante("sofia", 4.5);
        est1.mostrarInfo();

        // asignamos una nota inválida
        Estudiante est2 = new Estudiante("carlos", 6.0);  // Nota fuera de rango
        est2.mostrarInfo();

        // Intentar cambiar la nota con un valor inválido
        est2.setNota(-1);
        est2.mostrarInfo();

        // Cambiar la nota a un valor válido
        est2.setNota(3.7);
        est2.mostrarInfo();
    }
}

