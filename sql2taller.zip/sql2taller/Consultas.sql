-- Listamos a todos los empleados
SELECT * FROM empleados;

-- Mostramos los nombres de los empleados y sus correos 
SELECT Nombre_uno_empleado, Nombre_dos_empleado, Apellido_uno_empleado, Apellido_dos_empleado, Correo_electronico FROM empleados;

-- WHERE con igualdad: Empleados del departamento de TI (id=1)
SELECT * FROM empleados WHERE Id_empleado = 1;

-- WHERE con AND: Empleados mujeres del departamento de TI
SELECT * FROM empleados WHERE Id_departamento = 1 AND Genero = 'F';

-- WHERE con OR: Empleados de TI o Marketing
SELECT * FROM empleados WHERE Id_departamento = 1 OR Id_departamento = 2;

-- LIKE con %: Empleados cuyo apellido empieza con 'M'
SELECT * FROM empleados WHERE Apellido_uno_empleado OR Apellido_dos_empleado LIKE 'M%';

-- BETWEEN: Empleados contratados entre 2020 y 2022
SELECT * FROM empleados WHERE Fecha_contratacion BETWEEN '2020-01-01' AND '202212-31';

-- Mayor que: Cargos con salario base mayor a 4000
SELECT * FROM cargos WHERE Salario_base > 4000;

-- Menor que: Empleados nacidos después de 1990
SELECT * FROM empleados WHERE Fecha_nacimiento > '1990-01-01';

-- Combinación de condiciones: Empleados con LIKE y AND
SELECT * FROM empleados WHERE Nombre_uno_empleado LIKE 'A%' AND Nombre_dos_empleado LIKE '%A';