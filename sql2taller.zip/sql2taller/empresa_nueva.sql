-- vamos a crear la bd
CREATE DATABASE empresa_nueva;
-- vamos a utilizar la bd creada
USE empresa_nueva;
-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS departamentos(
Id_departamento INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_departamento VARCHAR (60) NOT NULL,
Ubicacion VARCHAR (60) NOT NULL
);

-- vamos a crear la segunda tabla independiente para la segunda tabla independiente del modelo MER

CREATE TABLE IF NOT EXISTS cargos(
Id_cargo INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_cargo VARCHAR (60) NOT NULL,
Descripcion VARCHAR (60) NOT NULL,
Salario_base DECIMAL (10,2) NOT NULL
);

-- Vamos a crear la tabla dependiente para la entidad empleado que es dependiente
-- Depende de departamentos y cargos
CREATE TABLE IF NOT EXISTS empleados(
Id_empleado INT UNIQUE NOT NULL PRIMARY KEY,
Id_departamento INT NOT NULL,
Id_cargo INT NOT NULL,
Fecha_contratacion DATE NOT NULL,
Correo_electronico VARCHAR(60) NOT NULL,
Fecha_nacimiento DATE NOT NULL,
Genero ENUM("M", "F", "Otro") NOT NULL,
Nombre_uno_empleado VARCHAR (60) NOT NULL,
Nombre_dos_empleado VARCHAR (60) NULL,
Apellido_uno_empleado VARCHAR (60) NOT NULL,
Apellido_dos_empleado VARCHAR (60) NULL,

CONSTRAINT fk_empleado_departamento FOREIGN KEY (Id_departamento) REFERENCES departamentos (Id_departamento),
CONSTRAINT fk_empleado_cargo FOREIGN KEY (Id_cargo) REFERENCES cargos (Id_cargo)
);
-- Vamos a crear otra tabla dependiente para la entidad salario
-- Depende de empleados
CREATE TABLE IF NOT EXISTS salarios(
Id_salario INT UNIQUE NOT NULL PRIMARY KEY,
Id_empleado INT NOT NULL,
Monto DECIMAL (10,2) NOT NULL,
Fecha_inicio DATE NOT NULL,
Fecha_fin DATE NULL,

CONSTRAINT fk_salario_empleado FOREIGN KEY (Id_empleado) REFERENCES empleados (Id_empleado)
);
-- Vamos a crear la tabla independiente para la entidad proyectos
CREATE TABLE IF NOT EXISTS proyectos (
Id_proyecto INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_proyecto VARCHAR (60) NOT NULL,
Descripcion_proyecto VARCHAR (60) NOT NULL,
Fecha_inicio DATE NOT NULL,
Fecha_fin DATE NULL

);
CREATE TABLE IF NOT EXISTS empleado_proyecto(
PRIMARY KEY (Id_empleado, Id_proyecto),
Id_empleado INT NOT NULL,
Id_proyecto INT NOT NULL,
CONSTRAINT fk_empleado_proyecto_empleado FOREIGN KEY (Id_empleado) REFERENCES empleados (Id_empleado),
CONSTRAINT fk_empleado_proyecto_proyecto FOREIGN KEY (Id_proyecto) REFERENCES proyectos (Id_proyecto)

);
