-- ahora hacemos la insercion de datos de ejemplo
-- "pacientes"
INSERT INTO Paciente (numero_historia_clinica, nombre, direccion, telefono) VALUES
(2001, 'Juan Rodríguez',      'Calle 45 #12-34, Barranquilla',  '3001234567'),
(2002, 'Carlos Moreno',        'Carrera 7 #45-23, Medellin',       '3109876543'),
(2003, 'claudia Vargas',         'Av. Bolívar #10-15, popayan',         '3205554433'),
(2004, 'Andrés Sandoval',      'Calle 20 #90-11, Cali',             '3171122334'),
(2005, 'Sofía Hernández',      'Cl. 30 #15-50, Cartagena',          '3189988776');
-- "medicos"
INSERT INTO Medico (numero_colegiatura, nombre, especialidad) VALUES
(5001, 'Dr. Andrés Pérez',     'Cardiología'),
(5002, 'Dra. Laura Gómez',      'Pediatría'),
(5003, 'Dr. Miguel Torres',     'Neurología'),
(5004, 'Dra. Camila Sánchez',   'Dermatología'),
(5005, 'Dr. Santiago Ruiz',     'Traumatología');
-- "cita"
INSERT INTO Cita (id_cita, fecha, hora, numero_historia_clinica, numero_colegiatura) VALUES
(1,   '2025-11-15', '09:00:00', 2001, 5001),
(2,   '2025-11-15', '10:30:00', 2002, 5002),
(3,   '2025-11-16', '11:00:00', 2001, 5003),
(4,   '2025-11-17', '14:00:00', 2003, 5001),
(5,   '2025-11-17', '15:30:00', 2003, 5002),
(6,   '2025-11-18', '08:00:00', 2004, 5004),
(7,   '2025-11-18', '09:45:00', 2005, 5005),
(8,   '2025-11-19', '13:15:00', 2005, 5002),
(9,   '2025-11-20', '10:00:00', 2002, 5001),
(10,  '2025-11-21', '16:00:00', 2004, 5003);
