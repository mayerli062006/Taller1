-- vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS tienda;
USE tienda;
CREATE TABLE IF NOT EXISTS Clientes (
ID_cliente INT NOT NULL,
nombre_cliente VARCHAR(30) NOT NULL,
nombredos_cliente VARCHAR(30),
apellido_cliente VARCHAR(30) NOT NULL,
apellidodos_cliente VARCHAR(30) NOT NULL,
correo_electronico VARCHAR(30) NOT NULL,
PRIMARY KEY (ID_cliente)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Productos (
codigo_producto INT NOT NULL,
nombre VARCHAR(30) NOT NULL,
descripcion VARCHAR(255),
precio DECIMAL(10,2) NOT NULL,
PRIMARY KEY (codigo_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Pedidos (
Id_pedido INT NOT NULL,
fecha_pedido DATE NOT NULL,
ID_cliente INT NOT NULL,
PRIMARY KEY (Id_pedido),
FOREIGN KEY (ID_cliente) REFERENCES Clientes(ID_cliente)
ON DELETE RESTRICT
ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS DetallePedido (
Id_pedido INT NOT NULL,
codigo_producto INT NOT NULL,
cantidad INT NOT NULL,
PRIMARY KEY (Id_pedido, codigo_producto),
FOREIGN KEY (Id_pedido) REFERENCES Pedidos(Id_pedido)
ON DELETE CASCADE
ON UPDATE CASCADE,
FOREIGN KEY (codigo_producto) REFERENCES Productos(codigo_producto)
ON DELETE RESTRICT
ON UPDATE CASCADE
) ENGINE=InnoDB;



