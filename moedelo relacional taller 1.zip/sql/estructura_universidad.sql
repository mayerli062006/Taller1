CREATE DATABASE IF NOT EXISTS store;
USE store;
CREATE TABLE Profesor (
Codigo_Profesor INT PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Especialidad VARCHAR(50) NOT NULL
);
-- Tabla ESTUDIANTE
CREATE TABLE Estudiante (
Numero_Matricula INT PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Correo VARCHAR(100) NOT NULL
);

-- Tabla CURSO
CREATE TABLE Curso (
Codigo_Curso INT PRIMARY KEY,
Nombre VARCHAR(100) NOT NULL,
Creditos INT NOT NULL,
Codigo_Profesor INT NOT NULL,
-- clave foránea hacia Profesor
FOREIGN KEY (Codigo_Profesor)
REFERENCES Profesor (Codigo_Profesor)
ON DELETE RESTRICT
ON UPDATE CASCADE
);
-- Tabla INSCRIPCION (tabla intermedia para la relación M:N entre Estudiante y Curso)
CREATE TABLE Inscripcion (
Numero_Matricula INT NOT NULL,
Codigo_Curso INT NOT NULL,
PRIMARY KEY (Numero_Matricula, Codigo_Curso),
FOREIGN KEY (Numero_Matricula)
REFERENCES Estudiante (Numero_Matricula)
ON DELETE CASCADE
ON UPDATE CASCADE,
FOREIGN KEY (Codigo_Curso)
REFERENCES Curso (Codigo_Curso)
ON DELETE CASCADE
ON UPDATE CASCADE
);