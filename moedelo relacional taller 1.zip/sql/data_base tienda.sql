-- insertamos datos de ejemplo
-- Clientes
INSERT INTO Clientes VALUES (1, 'Juan', 'Andrés', 'Pérez', 'Gómez', 'juan.perez@example.com');
INSERT INTO Clientes VALUES (2, 'María', NULL, 'Rodríguez', 'López', 'maria.rodriguez@example.com');

-- Productos
INSERT INTO Productos VALUES (100, 'Camiseta', 'Camiseta de algodón talla M', 29.99);
INSERT INTO Productos VALUES (101, 'Pantalón', 'Pantalón denim azul', 49.99);
INSERT INTO Productos VALUES (102, 'Gorra', 'Gorra deportiva negra', 19.99);

-- Pedidos
INSERT INTO Pedidos VALUES (10, '2025-11-10', 1);
INSERT INTO Pedidos VALUES (11, '2025-11-11', 2);

-- DetallePedido
INSERT INTO DetallePedido VALUES (10, 100, 2);  
INSERT INTO DetallePedido VALUES (10, 102, 1);  
INSERT INTO DetallePedido VALUES (11, 101, 1);  
INSERT INTO DetallePedido VALUES (11, 102, 2);  
