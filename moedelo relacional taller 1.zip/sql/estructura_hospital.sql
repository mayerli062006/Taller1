-- vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS hospital;
-- voy a utilizar la bd creada
USE hospital;
-- creo la primer tabla "paciente"
CREATE TABLE Paciente (
numero_historia_clinica INT PRIMARY KEY,
nombre VARCHAR(100) NOT NULL,
direccion VARCHAR(200),
telefono VARCHAR(20)
);
-- creo la segunda tabla "medico"
CREATE TABLE Medico (
numero_colegiatura INT PRIMARY KEY,
nombre VARCHAR(100) NOT NULL,
especialidad VARCHAR(100)
);
-- creo la tercer tabla"cita"
CREATE TABLE Cita (
id_cita INT PRIMARY KEY,
fecha DATE NOT NULL,
hora TIME NOT NULL,
numero_historia_clinica INT NOT NULL,
numero_colegiatura INT NOT NULL,
FOREIGN KEY (numero_historia_clinica) REFERENCES Paciente(numero_historia_clinica),
FOREIGN KEY (numero_colegiatura) REFERENCES Medico(numero_colegiatura)
);



