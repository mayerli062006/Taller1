-- Profesores
INSERT INTO Profesor (Codigo_Profesor, Nombre, Especialidad) VALUES
(1, 'Carlos Gómez', 'Matemáticas'),
(2, 'Luisa Martínez', 'Programación'),
(3, 'Andrés Ríos', 'Física');

-- Estudiantes
INSERT INTO Estudiante (Numero_Matricula, Nombre, Correo) VALUES
(1001, 'Ana Torres', 'ana@mail.com'),
(1002, 'Luis Pérez', 'luis@mail.com'),
(1003, 'María Rojas', 'maria@mail.com');

-- Cursos
INSERT INTO Curso (Codigo_Curso, Nombre, Creditos, Codigo_Profesor) VALUES
(101, 'Cálculo I', 4, 1),
(102, 'Programación Básica', 3, 2),
(103, 'Física Mecánica', 4, 3);

-- Inscripciones
INSERT INTO Inscripcion (Numero_Matricula, Codigo_Curso) VALUES
(1001, 101),
(1001, 102),
(1002, 103),
(1003, 101),
(1003, 102);