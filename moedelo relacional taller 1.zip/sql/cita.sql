SELECT * FROM hospital.cita;

